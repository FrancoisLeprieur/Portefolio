<style>

body {
    font-family: 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
    background-color: #f4f7f6;
    color: #333;
    line-height: 1.6;
    padding: 40px;
}

h1 {
    color: #2c3e50;
    font-size: 1.8rem;
    margin-bottom: 5px;
    text-align: center;
}

h2 {
    color: #7f8c8d;
    font-size: 1.1rem;
    font-weight: 400;
    text-align: center;
    margin-bottom: 30px;
    text-transform: uppercase;
    letter-spacing: 1px;
}

ul {
    list-style: none;
    padding: 0;
    max-width: 500px;
    margin: 0 auto;
}

li {
    background: white;
    margin-bottom: 10px;
    padding: 15px 20px;
    border-radius: 12px;
    box-shadow: 0 2px 5px rgba(0,0,0,0.05);
    transition: transform 0.2s ease, box-shadow 0.2s ease;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

li:hover {
    transform: scale(1.02);
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    border-left: 4px solid #3498db;
}

strong {
    color: #3498db;
    font-weight: 700;
}


li:last-child {
    background: #fdf2f2; 
    border: 1px dashed #f1c2bd;
    color: #ca746b;
    font-size: 0.9rem;
    margin-top: 20px;
}

li:last-child strong {
    color: #e74c3c;
}

</style>


# Statistiques sur les arrêts de bus à Lyon

## Résultats 
* **Nombre total d'arrêts** :  5238
* **Taux d'équipement en bancs** :  36%
* **Taux de présence de poubelles** :  29%
* **Taux d'éclairage nocturne** :  31%
* **Données non renseignées** :  2046 arrêts sans informations. 