

<style>

body {
    font-family: 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
    background-color: #f4f7f6;
    color: #333;
    padding: 40px;
    display: flex;
    flex-direction: column;
    align-items: center;
}


h2 {
    color: #2c3e50;
    font-size: 1.8rem;
    text-align: center;
    margin-bottom: 30px;
    text-transform: uppercase;
    letter-spacing: 1px;
}

p {
    background: white;
    max-width: 600px;   
    width: 100%;         
    padding: 20px;
    margin-bottom: 20px;  
    border-radius: 12px;  
    box-shadow: 0 2px 5px rgba(0,0,0,0.05); 
    line-height: 1.6;
    transition: transform 0.2s ease, box-shadow 0.2s ease; 
}

p:hover {
    transform: scale(1.02);
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    border-left: 4px solid #3498db;
}

strong {
    color: #3498db; 
    font-weight: 700;
}

img {
    max-width: 100%;
    height: auto;
    border-radius: 8px;
    display: block;
    margin: 0 auto; 
}

</style>## Délices Magic Beau Gosse 
 </br>- **Liens OSM** : [Délices Magic Beau Gosse](https://www.openstreetmap.org/node/5553036408) 
 </br>- **amenity** : fast_food </br>- **check_date** : 2026-03-07 </br>- **contact:facebook** : delicesdelatour </br>- **contact:housenumber** : 29 </br>- **contact:street** : Boulevard des Alliés </br>- **cuisine** : kebab </br>- **delivery** : yes </br>- **name** : Délices Magic Beau Gosse </br>- **old_name** : Les Délices de la Tour </br>- **opening_hours** : Tu-Sa 11:00-04:00; Su 07:00-02:00 </br>- **payment:cards** : yes </br>- **payment:cash** : yes </br>- **phone** : +33 2 31 93 57 94 </br>- **ref:FR:SIRET** : 81819610700010 </br>- **takeaway** : yes </br>- **wheelchair** : yes </br>

![Carte de localisation](map.png)