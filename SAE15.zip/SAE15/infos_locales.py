from md_to_html import convert, cv
import markdown
import requests
import json
global css_info_local

css_info_local = """<style>

body {
    font-family: 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
    background-color: #f4f7f6;
    color: #333;
    line-height: 1.6;
    padding: 40px;
}

h1 {
    color: #2c3e50;
    font-size: 1.8rem;
    margin-bottom: 5px;
    text-align: center;
}

h2 {
    color: #7f8c8d;
    font-size: 1.1rem;
    font-weight: 400;
    text-align: center;
    margin-bottom: 30px;
    text-transform: uppercase;
    letter-spacing: 1px;
}

ul {
    list-style: none;
    padding: 0;
    max-width: 500px;
    margin: 0 auto;
}

li {
    background: white;
    margin-bottom: 10px;
    padding: 15px 20px;
    border-radius: 12px;
    box-shadow: 0 2px 5px rgba(0,0,0,0.05);
    transition: transform 0.2s ease, box-shadow 0.2s ease;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

li:hover {
    transform: scale(1.02);
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    border-left: 4px solid #3498db;
}

strong {
    color: #3498db;
    font-weight: 700;
}


li:last-child {
    background: #fdf2f2; 
    border: 1px dashed #f1c2bd;
    color: #ca746b;
    font-size: 0.9rem;
    margin-top: 20px;
}

li:last-child strong {
    color: #e74c3c;
}

</style>\n\n"""
        



def get_dataset(query: str) -> dict : 
    """Prend en argument une requete et nous renvoie un dictionnaire """
    url = "https://overpass-api.de/api/interpreter"
    paquet = {'data': query} 
    response = requests.post(url, data=paquet )
    return json.loads(response.text)



def compute_statistics(dataset: dict) -> dict:
    
    """Calcule des statistiques sur les équipements des arrêts de bus
    ,regarde si il y a des bancs, poubelles et éclairage"""
    
    elements = dataset.get("elements", [])
    total = len(elements)
    stats = {"total": total, "banc": 0, "poubelle": 0, "eclairage": 0, "incomplet": 0}
    if total == 0:
        return stats
    for item in elements:
        tags = item.get("tags", {})
        if tags.get("bench") == "yes":
            stats["banc"] += 1 
        if tags.get("bin") == "yes":
            stats["poubelle"] += 1 
        if tags.get("lit") == "yes":
            stats["eclairage"] += 1 
        if "bench" not in tags and "bin" not in tags and "lit" not in tags:
            stats["incomplet"] += 1      
    return stats



def dataset_to_md(dataset: dict, filename: str, ville: str) -> None:
    
    """Produit un fichier Markdown présentant les statistiques """
   
    total = dataset["total"]
    if total == 0:
        print("Aucune donnée à écrire.")
        return
    nb_bancs = dataset["banc"]
    nb_poubelles = dataset["poubelle"]
    nb_eclairage = dataset["eclairage"]
    pc_banc = round((nb_bancs / total) * 100)
    pc_poubelle = round((nb_poubelles / total) * 100)
    pc_eclairage = round((nb_eclairage / total) * 100)
    contenu = f"""{css_info_local}
# Statistiques sur les arrêts de bus à {ville}

## Résultats 
* **Nombre total d'arrêts** :  {total}
* **Taux d'équipement en bancs** :  {pc_banc}%
* **Taux de présence de poubelles** :  {pc_poubelle}%
* **Taux d'éclairage nocturne** :  {pc_eclairage}%
* **Données non renseignées** :  {dataset['incomplet']} arrêts sans informations. """
    with open(filename, "w", encoding="utf-8") as f:
        f.write(contenu)    
    print("Le markdown est créé")




def infos_locales(ville: str) -> None :
    
    """Fonction principale qui orchestre le téléchargement et la génération des fiches"""
    
    requete = f"""
    [out:json][timeout:25];
    area[name="{ville}"]->.searchArea;
    (node["highway"="bus_stop"](area.searchArea););
    out body;
    """ 
    print(f"Récupération des données pour {ville}...")
    donnees = get_dataset(requete)
    statistiques = compute_statistics(donnees)
    fichiermd = "stats_bus.md"
    fichierhtml = "stats_bus.html"
    dataset_to_md(statistiques, fichiermd, ville)
    cv()
    print(f"Fiches générées : {fichiermd} et {fichierhtml}")


  
if __name__ == "__main__":
    """Permet de lancer le programme depuis le terminal"""
    infos_locales("Lyon")


infos_locales("Lyon")