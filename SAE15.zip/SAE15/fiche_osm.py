from md_to_html import convert
import markdown
import requests
import math
import sys 
from PIL import Image, ImageDraw
import os

global css_fiche_osm

css_fiche_osm = """

<style>

body {
    font-family: 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
    background-color: #f4f7f6;
    color: #333;
    padding: 40px;
    display: flex;
    flex-direction: column;
    align-items: center;
}


h2 {
    color: #2c3e50;
    font-size: 1.8rem;
    text-align: center;
    margin-bottom: 30px;
    text-transform: uppercase;
    letter-spacing: 1px;
}

p {
    background: white;
    max-width: 600px;   
    width: 100%;         
    padding: 20px;
    margin-bottom: 20px;  
    border-radius: 12px;  
    box-shadow: 0 2px 5px rgba(0,0,0,0.05); 
    line-height: 1.6;
    transition: transform 0.2s ease, box-shadow 0.2s ease; 
}

p:hover {
    transform: scale(1.02);
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    border-left: 4px solid #3498db;
}

strong {
    color: #3498db; 
    font-weight: 700;
}

img {
    max-width: 100%;
    height: auto;
    border-radius: 8px;
    display: block;
    margin: 0 auto; 
}

</style>"""


def get_node (id : int) -> dict :
    """Cette Fonction prend en argument un id qui est un int avec cette int elle fait une requet"""
    liens = "https://www.openstreetmap.org/api/0.6/node/"+ str(id)+".json"
    tete = {'User-Agent': 'SAE105_Etudiant'}
    requete = requests.get(liens, headers=tete)
    fichierenjson = requete.json()
    noeud = fichierenjson['elements'][0]
    tags = noeud['tags']
    lat = noeud['lat'] 
    lon = noeud['lon'] 
    return tags, lat, lon


def deg2num(lat_deg : float , lon_deg : float , zoom : int):
    """Permet de transformer des degres en mètre """
    lat_rad = math.radians(lat_deg)
    n = 2.0 ** zoom
    xtile = int((lon_deg + 180.0) / 360.0 * n)
    ytile = int((1.0 - math.asinh(math.tan(lat_rad)) / math.pi) / 2.0 * n)
    return xtile, ytile


def generate_map(lat, lon, zoom=15):
    """Cette fonction localise la tuile avec les coordonnées, puis fait une requête pour la télécharger en 256×256. 
    Puis, avec PIL, on ajoute un marqueur au centre. """
    x = deg2num(lat, lon, zoom)[0]
    y = deg2num(lat, lon, zoom)[1]
    tete = {'User-Agent': 'SAE105_Etudiant'} # Permet d'accéder à l'api sinon c'est interdit 
    url = f"http://tile.openstreetmap.org/{zoom}/{x}/{y}.png"
    reponse = requests.get(url , headers = tete )
    nom_fichier = "map.png"
    with open("map.png", "wb") as f:
        f.write(reponse.content)
        img = Image.open(nom_fichier).convert("RGB")
        dessin = ImageDraw.Draw(img)
        rayon = 5
        center_x, center_y = 128, 128
        dessin.ellipse(
            [center_x - rayon, center_y - rayon, center_x + rayon, center_y + rayon],
            fill="red", 
            outline="black" )
        img.save(nom_fichier)
        print("Carte téléchargée avec succès : map.png")


def node_to_md (data: dict, filename: str , id : int) -> None :
    """Cette fonction convertit le dictionnaire OpenStreetMap en .md en ajoutant la mise en page aux tags voulus"""
    contenu = ""
    for key , value in data.items() :
        if key == "name" :
            contenu = f"## {value} \n </br>"
            contenu += f"- **Liens OSM** : [{value}](https://www.openstreetmap.org/node/{id}) \n </br>"
    for key, value in data.items():
        contenu += f"- **{key}** : {value} </br>"
    with open(filename, 'w', encoding='utf-8') as f:
        f.write(css_fiche_osm)
        f.write(contenu)
        f.write("\n\n![Carte de localisation](map.png)")



def fiche_osm(id: int) -> None :
    """Assemble les fonctions définies précédemment"""
    tags = get_node(id)[0]
    lat = get_node(id)[1]
    lon = get_node(id)[2]
    generate_map(lat, lon)
    node_to_md(tags,"input.md",id)
    convert()
    print("Le fichier markdown et html ont bien été créés.")


if __name__ == "__main__":
     """Permet de lancer le programme depuis le terminal"""
     id = int(sys.argv[1])
     fiche_osm(id)


