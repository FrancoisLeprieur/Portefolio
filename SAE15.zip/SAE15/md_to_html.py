import markdown


def convert ():
   with open('input.md', 'r') as f:
      text = f.read()
   html = markdown.markdown(text)
   with open('output.html', 'w') as f:
      f.write(html)



def cv ():
   with open('stats_bus.md', 'r') as f:
      text = f.read()
   html = markdown.markdown(text)
   with open('listedesbus.html', 'w') as f:
      f.write(html)
